import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.RecursiveAction;

public class MatrixAdd extends RecursiveAction {
    int[][] first, second, result;
    int row, colSize;

    private int workLength;

    public MatrixAdd(int[][]first, int[][] second, int[][] result, int row, int colSize, int workLength){
        this.first = first;
        this.second = second;
        this.result = result;
        this.row = row;
        this.colSize = colSize;
        this.workLength = workLength;
    }

    protected synchronized void execute(){
        for (int i = 0; i < colSize; i++){
            this.result[row][i] = first[row][i] + second[row][i];
        }
    }

    private List<MatrixAdd> createSubtasks() {
        List<MatrixAdd> subtasks =
                new ArrayList<MatrixAdd>();
        for (int i = 0; i < workLength; i++){
            subtasks.add(new MatrixAdd(first, second, result, row, colSize, 1));
        }
        return subtasks;
    }

    @Override
    protected void compute() {
        if (workLength == 1){
            execute();
            return;
        } else {
            invokeAll(createSubtasks());
        }

    }
}
