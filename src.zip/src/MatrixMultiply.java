import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.*;

public class MatrixMultiply extends RecursiveAction{

    // code to calculate entry at [row][col] of the resulting matrix
    // for addition

    int[][] first, second, result;
    int row, column, rowSize, colSize;

    private int workLength; // how many columns are computed by one job

    public MatrixMultiply(int[][]first, int[][] second, int[][] result, int row, int column, int rowSize, int colSize, int workLength){
        this.first = first;
        this.second = second;
        this.result = result;
        this.row = row;
        this.column = column;
        this.rowSize = rowSize;
        this.colSize = colSize;
        this.workLength = workLength;
    }

    protected synchronized void execute(){
        for (int i = 0; i < colSize; i++){
            this.result[row][column] += first[row][i]*second[i][column];
        }
    }

    private List<MatrixMultiply> createSubtasks() {
        List<MatrixMultiply> subtasks =
                new ArrayList<MatrixMultiply>();
        for (int r = 0; r < workLength; r++) {
            for (int i = 0; i < colSize; i++) {
                subtasks.add(new MatrixMultiply(first, second, result, r, i, rowSize, colSize, 1));
            }
        }
            return subtasks;
    }

    @Override
    protected void compute() {
        if (workLength == 1){
            execute();
            return;
        } else {
            invokeAll(createSubtasks());
        }

    }
}
