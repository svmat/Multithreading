import java.util.concurrent.*;

public class MatrixPoolImpl implements MatMath {
    ForkJoinPool pool = new ForkJoinPool();

    @Override
    public void multiply(int[][] A, int[][] B, int[][] C) {
        int size = A[0].length;
        MatrixMultiply fja = new MatrixMultiply(A, B, C, 0, 0, A.length, size, A.length);
        pool.invoke(fja);

    }

    @Override
    public void add(int[][] A, int[][] B, int[][] C) {
        MatrixAdd fja = new MatrixAdd(A, B, C,0, A[0].length, A.length);
        pool.invoke(fja);
    }

    @Override
    public void print(int[][] A, Timer t) {
        for (int row = 0; row < A.length; row++) {

            for (int col = 0; col < A[row].length; col++) {
                t.print(A[row][col] + " ");
            }
            t.print("\n");
        }
        t.print("\n");
    }
}
