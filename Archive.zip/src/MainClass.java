import javax.imageio.IIOException;
import java.io.IOException;
import java.util.Random;
import java.util.stream.IntStream;

class MainClass {
    static final int SIZE_ADD = 4000;
    static final int SIZE_M = 1000;

    public static void main(String[] args) {
        int[][] A = new int[SIZE_ADD][SIZE_ADD];
        int[][] B = new int[SIZE_ADD][SIZE_ADD];
        int[][] C = new int[SIZE_M][SIZE_M];
        int[][] D = new int[SIZE_M][SIZE_M];
        int[][] r = new int[SIZE_ADD][SIZE_ADD];
        int[][] s = new int[SIZE_M][SIZE_M];
        Timer timeCount = new Timer();
        long start;

        MathMathSeqImpl uSeq = new MathMathSeqImpl();
        MathStreamImpl uStream = new MathStreamImpl();

        // code to initialize A,B,C,D
        Random rand = new Random();
        IntStream.range(0, SIZE_ADD).forEach(rowInt -> {
            IntStream.range(0, SIZE_ADD).forEach(colInt -> {
                A[rowInt][colInt] = rand.nextInt(20);
                B[rowInt][colInt] = rand.nextInt(20);
            });
        });

        IntStream.range(0, SIZE_M).forEach(rowInt -> {
            IntStream.range(0, SIZE_M).forEach(colInt -> {
                C[rowInt][colInt] = rand.nextInt(20);
                D[rowInt][colInt] = rand.nextInt(20);
            });
        });

        // warmup
        uStream.add(A, B, r);
        uStream.multiply(C, D, s);
        uSeq.add(A, B, r);
        uSeq.multiply(C, D, s);

        start = timeCount.writeStartTime("Adding two matrices sequentially");
        uSeq.add(A, B, r);
        timeCount.writeElapsedTime("Adding two matrices sequentially", start);

        start = timeCount.writeStartTime("Adding two matrices with stream");
        uStream.add(A, B, r);
        timeCount.writeElapsedTime("Adding two matrices with stream", start);


        start = timeCount.writeStartTime("Multiplying to matrices sequentially");
        uSeq.multiply(C, D, s);
        timeCount.writeElapsedTime("Multiplying two matrices sequentially", start);

        start = timeCount.writeStartTime("Multiplying two matrices with stream");
        uStream.multiply(C, D, s);
        timeCount.writeElapsedTime("Multiplying two matrices with stream", start);

        timeCount.close();
    }

}